import java.util.Scanner;
import java.util.Random;

/**
 *  @author Jaryn Bibb
 *  @version 1.1
 *  "Coliseum of Code"
 *  Fall 2026
 */
public class Main {

	public static <T> void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		Random rand = new Random();
		int roundCount1 = 0;
		int roundCount2 = 0;
		Fighter fighter1 = new Fighter("HyperLink", 100, 15, 0) {
			/**
			* swapTurns will be used for each fighter and will dictate their available options and
			* how their damage, received or dealt, is calculated
			*/
			public void swapTurns(Fighter fighter1, Fighter fighter2, Scanner scanner) {
				if (fighter1.isSpecialFull() == true) {
				    System.out.println("It is your turn! Press 1 to attack or press 2 to use a special attack!");
				} else {
					System.out.println("It is your turn! Press 1 to attack!");
				}
				System.out.println("(You) " + fighter1.getFighterName() + "'s current stats - HP: " + fighter1.getHealth() + ", SM: " + fighter1.getSpecialMeter());
				int choice = scnr.nextInt();
				if (choice == 1) {
					int damageDealt1 = fighter1.calculateDamage();
					fighter2.health = fighter2.health - damageDealt1;
					System.out.println(fighter1.getFighterName() + " has used normal attack!");
					fighter2.takeDamage();
					System.out.println("");
				} else if (choice == 2 && fighter1.isSpecialFull() == true) {
					fighter1.unleashSpecialAttack();
					int damageDealt1 = fighter1.calculateDamage();
					fighter2.health = fighter2.health - (damageDealt1 * 3);
					fighter2.takeDamage();
					System.out.println("");
				}
			}
		};
		Fighter fighter2 = new Fighter("Arraiden", 100, 15, 0) {
			public void swapTurns(Fighter fighter1, Fighter fighter2, Scanner scanner) {
				System.out.println("It is now the opponents turn!");
				System.out.println("(AI) " + fighter2.getFighterName() + "'s current stats - HP: " + fighter2.getHealth() + ", SM: " + fighter2.getSpecialMeter());
				int coinFlip = rand.nextInt(2);
				if (coinFlip == 0) {
					int damageDealt2 = fighter2.calculateDamage();
					fighter1.health = fighter1.health - damageDealt2;
					System.out.println(fighter2.getFighterName() + " has used normal attack!");
					fighter1.takeDamage();
					System.out.println("");
				} else if (coinFlip == 1 && fighter2.isSpecialFull() == true) {
					fighter2.unleashSpecialAttack();
					int damageDealt2 = fighter2.calculateDamage();
					fighter1.health = fighter1.health - (damageDealt2 * 3);
					fighter1.takeDamage();
					System.out.println("");
				} else if (coinFlip == 1) {
					int damageDealt2 = fighter2.calculateDamage();
					fighter1.health = fighter1.health - damageDealt2;
					System.out.println(fighter2.getFighterName() + " has used normal attack!");
					fighter1.takeDamage();
					System.out.println("");
				}
			}
		};
		Stage<Fighter> stage = new Stage<>(fighter1, fighter2);
		
		stage.startMatch();
		while (fighter1.isAlive() == true && fighter2.isAlive() == true) {
			fighter1.swapTurns(fighter1, fighter2, scnr);
			fighter2.swapTurns(fighter1, fighter2, scnr);
			if (fighter1.isAlive() == false) {
				stage.announceWinner();
				stage.roundsWon.add(fighter2);
				roundCount2++;
				fighter1.resetStats();
				fighter2.resetStats();
			}
			if (fighter2.isAlive() == false) {
				stage.announceWinner();
				stage.roundsWon.add(fighter1);
				roundCount1++;
				fighter1.resetStats();
				fighter2.resetStats();
			}
			if (roundCount1 == 2) {
				break;
			} else if (roundCount2 == 2) {
				break;
			}
		}
		if (roundCount1 == 2) {
			System.out.println("Coungratulations! Looks like your fighter, " + fighter1.getFighterName() + " has won the match!");
		}
		if (roundCount2 == 2) {
			System.out.println("Uh oh! Looks like " + fighter2.getFighterName() + " has won the match! Try again?");
		}
    }
}
