import java.util.ArrayList;

/**
 *  @author Jaryn Bibb
 *  @version 1.1
 *  "Coliseum of Code"
 *  Fall 2026
 */

public class Stage<T extends Fighter> {
	private T fighter1;
	private T fighter2;
	
	public ArrayList<T> roundsWon = new ArrayList<>();
	
	public Stage(T fighter1, T fighter2) {
		this.fighter1 = fighter1;
		this.fighter2 = fighter2;
	}
	public void startMatch() {
		System.out.println("We have " + fighter1.getFighterName() + " and " + fighter2.getFighterName() + " stepping into the ring! Ready...");
		System.out.println("FIGHT!");
	}
	public void announceWinner() {
		if (fighter2.isAlive() == false) {
			System.out.println(fighter2.getFighterName() + " has been knocked down! " + fighter1.getFighterName() + " claims this round!");
	} else if (fighter1.isAlive() == false) {
			System.out.println(fighter1.getFighterName() + " has been knocked down! " + fighter2.getFighterName() + " wins this round!");
	}
}
}