import java.util.Scanner;

/**
 *  @author Jaryn Bibb
 *  @version 1.1
 *  "Coliseum of Code"
 *  Fall 2026
 */

public abstract class Fighter {
	protected String fighterName;
	protected int health;
	protected int power;
	protected int specialMeter;
	protected final int FULL_SPECIAL = 100;
	
	/**
	 * The empty-argument constructor should initialize the instance variables
	 */
	public Fighter() {
		fighterName = "";
		health = 0;
		power = 0;
		specialMeter = 0;
	} //end constructor
	/**
	 * @param fighterName the value of fighterName based on the calling method
	 * @param health the value of health based on the calling method
	 * @param power the value of power based on the calling method
	 * @param specialMeter the value of specialMeter based on the calling method
	 */
	public Fighter(String fighterName, int health, int power, int specialMeter) {
		this.fighterName = fighterName;
		this.health = health;
		this.power = power;
		this.specialMeter = specialMeter;
	}// end constructor
	/**
	 * This method checks if the active fighter is still alive
	 * @return true if health is above 0, false if otherwise 
	 */
	public boolean isAlive() {
		if (health > 0) {
			return true;
		} else {
			return false;
		}
	} //end isAlive
	/**
	 * This method notifies the fighter that they've taken damage and builds up their meter by a random number
	 */
	public void takeDamage() {
		System.out.println(fighterName + " has taken damage!");
		specialMeter = specialMeter + (int) (Math.random() * 16) + 10;
	} //end takeDamage
	/**
	 * This method calculates the amount of damage a fighter deals by multiplying a random number with their power
	 */
	public int calculateDamage() {
		return (int) (Math.random() * power);
	} //end calculateDamage
	/**
	 * This method checks if a fighters special meter is full
	 * @return true if the fighters special meter is full, false if otherwise
	 */
	public boolean isSpecialFull() {
		if (specialMeter >= FULL_SPECIAL) {
			return true;
		} else {
			return false;
		}
	} //end isSpecialFull
	/**
	 * This method makes a fighter execute a special move and resets their meter to 0 if used
	 */
	public void unleashSpecialAttack() {
		System.out.println(fighterName + "has unleashed a special attack!");
		specialMeter = 0;
	} //end unleashSpecialAttack
	/**
	 * This method resets a fighters health and special meter back to their normal values after a round
	 */
	public void resetStats() {
		health = 100;
		specialMeter = 0;
	} //end resetStats
	public abstract void swapTurns(Fighter user, Fighter opponent, Scanner scanner);
	
	/**
	 * @param the current value of fighterName
	 */
	public String getFighterName() {
		return fighterName;
	}
	//end getFighterName
	/**
	 * @param the value of fighterName to be set
	 */
	public void setFighterName(String fighterName) {
		this.fighterName = fighterName;
	}
	//end setFigherName
	/**
	 * @param the current value of health
	 */
	public int getHealth() {
		return health;
	}
	//end getHealth
	/**
	 * @param the value of health to be set
	 */
	public void setHealth(int health) {
		this.health = health;
	}
	//end setHealth
	/**
	 * @param the current value of power
	 */
	public int getPower() {
		return power;
	}
	//end getPower
	/**
	 * @param the value of power to be set
	 */
	public void setPower(int power) {
		this.power = power;
	}
	//end setPower
	/**
	 * @param the current value of specialMeter
	 */
	public int getSpecialMeter() {
		return specialMeter;
	}
	//end getSpecialMeter
	/**
	 * @param the value of fighterName to be set
	 */
	public void setSpecialMeter(int specialMeter) {
		this.specialMeter = specialMeter;
	}
	//end setSpecialMeter
}//end class
